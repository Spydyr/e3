#
# buildroot/share/PlatformIO/scripts/mks_robin_pro.py
#
import marlin
marlin.prepare_robin("0x08007000", "mks_robin_pro.ld", "Robin_pro.bin")
